
Using the Action_Bar_Icons_Export.jsx script:

*** To run the script in Illustrator, select "file > scripts > other scripts" and browse to open the script.

*** All shapes must be flattened into a single compound path. Use the "expand appearance" tool to create a compound path.